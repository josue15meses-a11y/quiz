import { FunnelData, Lead, PainDistribution } from '../types';

export const mockFunnelData: FunnelData = {
  visitors: 1000,
  startedQuiz: 650,
  answeredQ1: 580,
  answeredQ2: 520,
  answeredQ3: 480,
  answeredQ4: 450,
  viewedVSL: 320,
  clickedBuy: 85,
};

export const mockPainDistribution: PainDistribution[] = [
  { name: 'Indiferencia', value: 45 },
  { name: 'Incertidumbre', value: 35 },
  { name: 'Desvalorización', value: 20 },
];

export const mockFearDistribution: PainDistribution[] = [
  { name: 'Ansiedad/Autoestima', value: 40 },
  { name: 'Él encontrará otra', value: 38 },
  { name: 'Desperdiciar años', value: 22 },
];

export const mockLeads: Lead[] = [
  {
    email: 'maria@example.com',
    situation: 'A',
    pain: 'A',
    implication: 'A',
    need: 'A',
    timestamp: new Date('2026-01-01T10:30:00'),
  },
  {
    email: 'sofia@example.com',
    situation: 'B',
    pain: 'B',
    implication: 'B',
    need: 'B',
    timestamp: new Date('2026-01-01T11:15:00'),
  },
  {
    email: 'carmen@example.com',
    situation: 'C',
    pain: 'A',
    implication: 'C',
    need: 'C',
    timestamp: new Date('2026-01-01T12:45:00'),
  },
  {
    situation: 'A',
    pain: 'C',
    implication: 'B',
    need: 'A',
    timestamp: new Date('2026-01-01T13:20:00'),
  },
  {
    email: 'lucia@example.com',
    situation: 'B',
    pain: 'A',
    implication: 'A',
    need: 'B',
    timestamp: new Date('2026-01-01T14:00:00'),
  },
];
