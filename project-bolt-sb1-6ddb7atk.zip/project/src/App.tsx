import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QuizProvider } from './contexts/QuizContext';
import Welcome from './pages/Welcome';
import Quiz from './pages/Quiz';
import Processing from './pages/Processing';
import VSL from './pages/VSL';
import Admin from './pages/Admin';

function App() {
  return (
    <Router>
      <QuizProvider>
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/processing" element={<Processing />} />
          <Route path="/vsl" element={<VSL />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </QuizProvider>
    </Router>
  );
}

export default App;
