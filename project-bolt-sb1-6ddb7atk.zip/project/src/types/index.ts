export interface QuizAnswer {
  question: number;
  answer: string;
}

export interface Lead {
  email?: string;
  situation: string;
  pain: string;
  implication: string;
  need: string;
  timestamp: Date;
}

export interface FunnelData {
  visitors: number;
  startedQuiz: number;
  answeredQ1: number;
  answeredQ2: number;
  answeredQ3: number;
  answeredQ4: number;
  viewedVSL: number;
  clickedBuy: number;
}

export interface PainDistribution {
  name: string;
  value: number;
}
