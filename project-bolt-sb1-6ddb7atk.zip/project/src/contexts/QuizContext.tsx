import React, { createContext, useContext, useState, ReactNode } from 'react';
import { QuizAnswer } from '../types';

interface QuizContextType {
  answers: QuizAnswer[];
  addAnswer: (question: number, answer: string) => void;
  email: string;
  setEmail: (email: string) => void;
  resetQuiz: () => void;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export const QuizProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [answers, setAnswers] = useState<QuizAnswer[]>([]);
  const [email, setEmailState] = useState('');

  const addAnswer = (question: number, answer: string) => {
    setAnswers((prev) => {
      const filtered = prev.filter((a) => a.question !== question);
      return [...filtered, { question, answer }];
    });
  };

  const setEmail = (email: string) => {
    setEmailState(email);
  };

  const resetQuiz = () => {
    setAnswers([]);
    setEmailState('');
  };

  return (
    <QuizContext.Provider value={{ answers, addAnswer, email, setEmail, resetQuiz }}>
      {children}
    </QuizContext.Provider>
  );
};

export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (!context) {
    throw new Error('useQuiz must be used within QuizProvider');
  }
  return context;
};
