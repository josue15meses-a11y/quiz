import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  mockFunnelData,
  mockPainDistribution,
  mockFearDistribution,
  mockLeads,
} from '../utils/mockData';
import { Users, TrendingDown, Mail } from 'lucide-react';

const COLORS = ['#6D28D9', '#8B5CF6', '#A78BFA', '#C4B5FD'];

export default function Admin() {
  const funnelChartData = [
    { stage: 'Visitantes', count: mockFunnelData.visitors },
    { stage: 'Inició Quiz', count: mockFunnelData.startedQuiz },
    { stage: 'Q1', count: mockFunnelData.answeredQ1 },
    { stage: 'Q2', count: mockFunnelData.answeredQ2 },
    { stage: 'Q3', count: mockFunnelData.answeredQ3 },
    { stage: 'Q4', count: mockFunnelData.answeredQ4 },
    { stage: 'Vio VSL', count: mockFunnelData.viewedVSL },
    { stage: 'Clic Compra', count: mockFunnelData.clickedBuy },
  ];

  const conversionRate = (
    (mockFunnelData.clickedBuy / mockFunnelData.visitors) *
    100
  ).toFixed(2);

  const getPainLabel = (answer: string) => {
    const labels: Record<string, string> = {
      A: 'Indiferencia',
      B: 'Incertidumbre',
      C: 'Desvalorización',
    };
    return labels[answer] || answer;
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-[#D97706] mb-2">Dashboard Administrativo</h1>
          <p className="text-gray-400">Analytics del Embudo de Conversión</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="bg-[#1A1A1A] p-6 rounded-lg border border-[#6D28D9]"
          >
            <div className="flex items-center gap-4">
              <Users className="w-12 h-12 text-[#6D28D9]" />
              <div>
                <p className="text-gray-400 text-sm">Total Visitantes</p>
                <p className="text-3xl font-bold">{mockFunnelData.visitors}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-[#1A1A1A] p-6 rounded-lg border border-[#D97706]"
          >
            <div className="flex items-center gap-4">
              <TrendingDown className="w-12 h-12 text-[#D97706]" />
              <div>
                <p className="text-gray-400 text-sm">Tasa de Conversión</p>
                <p className="text-3xl font-bold">{conversionRate}%</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-[#1A1A1A] p-6 rounded-lg border border-[#8B5CF6]"
          >
            <div className="flex items-center gap-4">
              <Mail className="w-12 h-12 text-[#8B5CF6]" />
              <div>
                <p className="text-gray-400 text-sm">Leads Capturados</p>
                <p className="text-3xl font-bold">{mockLeads.filter((l) => l.email).length}</p>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-[#1A1A1A] p-6 rounded-lg mb-8"
        >
          <h2 className="text-2xl font-bold text-[#6D28D9] mb-6">Embudo de Conversión</h2>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={funnelChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="stage" stroke="#888" />
              <YAxis stroke="#888" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1A1A1A', border: '1px solid #6D28D9' }}
              />
              <Bar dataKey="count" fill="#6D28D9" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-[#1A1A1A] p-6 rounded-lg"
          >
            <h2 className="text-2xl font-bold text-[#D97706] mb-6">
              Análisis de Dolores (Q2)
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={mockPainDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {mockPainDistribution.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1A1A1A', border: '1px solid #6D28D9' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-[#1A1A1A] p-6 rounded-lg"
          >
            <h2 className="text-2xl font-bold text-[#D97706] mb-6">
              Análisis de Miedo (Q3)
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={mockFearDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {mockFearDistribution.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1A1A1A', border: '1px solid #6D28D9' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-[#1A1A1A] p-6 rounded-lg"
        >
          <h2 className="text-2xl font-bold text-[#6D28D9] mb-6">Tabla de Leads</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-[#6D28D9]">
                <tr>
                  <th className="text-left py-3 px-4">Email</th>
                  <th className="text-left py-3 px-4">Dolor Principal (Q2)</th>
                  <th className="text-left py-3 px-4">Fecha</th>
                </tr>
              </thead>
              <tbody>
                {mockLeads.map((lead, index) => (
                  <motion.tr
                    key={index}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className="border-b border-gray-800 hover:bg-[#2A2A2A] transition-colors"
                  >
                    <td className="py-3 px-4">
                      {lead.email || <span className="text-gray-500 italic">No capturado</span>}
                    </td>
                    <td className="py-3 px-4">{getPainLabel(lead.pain)}</td>
                    <td className="py-3 px-4">
                      {lead.timestamp.toLocaleDateString('es-ES', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
