import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const DELAY_SECONDS = 505;

export default function VSL() {
  const [showButton, setShowButton] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowButton(true);
    }, DELAY_SECONDS * 1000);

    return () => {
      clearTimeout(timer);
    };
  }, []);

  const handleBuyClick = () => {
    alert('Redirigiendo a la página de pago...');
  };

  return (
    <div className="min-h-screen bg-white px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-[#6D28D9] to-[#5B21B6] text-center py-8 px-6 rounded-lg mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-[#D97706] mb-4">
            RESULTADO: ENTRASTE EN LA 'ZONA DE GARANTÍA' 🚨
          </h1>
          <p className="text-white text-lg leading-relaxed max-w-3xl mx-auto">
            Tus respuestas muestran que te convertiste en una GARANTÍA para él. Entregaste el premio
            antes de que él pagara el precio. Su instinto de caza se apagó. La culpa no es tuya, es
            biológica. Mira el video abajo para revertir esto:
          </p>
        </motion.div>

        <div className="flex justify-center mb-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="aspect-[9/16] w-full max-w-sm bg-black rounded-lg flex items-center justify-center shadow-2xl"
          >
            <p className="text-white text-xl font-semibold text-center px-4">
              [VIDEO VSL AQUÍ]
            </p>
          </motion.div>
        </div>

        <AnimatePresence>
          {showButton && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <motion.button
                onClick={handleBuyClick}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                animate={{
                  boxShadow: [
                    '0 0 0 0 rgba(109, 40, 217, 0.4)',
                    '0 0 0 20px rgba(109, 40, 217, 0)',
                  ],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  repeatType: 'loop',
                }}
                className="bg-gradient-to-r from-[#6D28D9] to-[#8B5CF6] text-white px-10 py-5 rounded-lg text-xl font-bold border-2 border-[#D97706] shadow-2xl inline-flex items-center gap-3"
              >
                QUIERO APLICAR EL MÉTODO Y REVERTIR AHORA
                <ArrowRight className="w-6 h-6" />
              </motion.button>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-6 text-gray-600"
              >
                <p className="text-sm">Acceso inmediato al protocolo completo</p>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
