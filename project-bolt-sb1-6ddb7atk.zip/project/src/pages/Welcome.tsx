import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Welcome() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-2xl w-full text-center"
      >
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#6D28D9] mb-6 leading-tight">
          DIAGNÓSTICO: ¿POR QUÉ ÉL SE ENFRIÓ O NO SE COMPROMETE? 💔
        </h1>

        <p className="text-lg md:text-xl text-gray-700 mb-8 leading-relaxed">
          Descubre el motivo real por el que se alejó o te está dando vueltas. En el 90% de los
          casos, existe un patrón de comportamiento tuyo que está bloqueando su instinto biológico.
        </p>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate('/quiz')}
          className="bg-[#6D28D9] text-white px-8 py-4 rounded-lg text-lg font-semibold border-2 border-[#D97706] shadow-lg hover:shadow-xl transition-shadow inline-flex items-center gap-2"
        >
          COMENZAR EL DIAGNÓSTICO
          <ArrowRight className="w-5 h-5" />
        </motion.button>
      </motion.div>
    </div>
  );
}
