import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useQuiz } from '../contexts/QuizContext';
import { ArrowRight } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: { id: string; text: string }[];
}

const questions: Question[] = [
  {
    id: 1,
    question: 'Para que el diagnóstico sea preciso, ¿qué frase describe mejor tu situación hoy?',
    options: [
      { id: 'A', text: "El 'Casi Algo' Eterno: Actuamos como novios, pero él huye del compromiso serio." },
      { id: 'B', text: 'El Marido/Novio Frío: Ya tenemos compromiso, pero él cambió y está distante.' },
      { id: 'C', text: "El 'Va y Viene': Él desaparece, después reaparece, y desaparece de nuevo." },
    ],
  },
  {
    id: 2,
    question: '¿Qué es lo que más te duele de su comportamiento hoy?',
    options: [
      { id: 'A', text: "La Indiferencia: Me deja en 'visto' y no responde, o tarda horas." },
      { id: 'B', text: 'La Incertidumbre: Una hora es un amor, a la otra es un hielo.' },
      { id: 'C', text: 'La Desvalorización: Yo hago todo por la relación y él solo recibe.' },
    ],
  },
  {
    id: 3,
    question:
      'Si continúas actuando exactamente como actúas hoy por los próximos 6 meses, ¿qué sientes que va a pasar?',
    options: [
      { id: 'A', text: 'Me voy a volver loca de ansiedad y mi autoestima se acabará.' },
      { id: 'B', text: 'Él se va a hartar definitivamente y encontrará a otra mujer.' },
      { id: 'C', text: 'Voy a desperdiciar mis mejores años con alguien que no me prioriza.' },
    ],
  },
  {
    id: 4,
    question:
      'Imagina que pudieras apretar un botón e invertir el juego hoy. ¿Qué sería lo más importante para ti?',
    options: [
      { id: 'A', text: 'Recuperar mi dignidad (hacer que él corra detrás de mí).' },
      { id: 'B', text: 'Tener seguridad emocional (ser asumida y ser prioridad).' },
      { id: 'C', text: 'Ser valorada (sentir que él me admira y me desea).' },
    ],
  },
];

export default function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const { addAnswer } = useQuiz();
  const navigate = useNavigate();

  const handleAnswer = (answer: string) => {
    addAnswer(questions[currentQuestion].id, answer);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
    } else {
      navigate('/processing');
    }
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen bg-white px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
              className="h-full bg-gradient-to-r from-[#D97706] to-[#F59E0B]"
            />
          </div>
          <p className="text-sm text-gray-600 mt-2 text-center">
            Pregunta {currentQuestion + 1} de {questions.length}
          </p>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.4 }}
            className="bg-white"
          >
            <h2
              className={`text-2xl md:text-3xl font-bold mb-8 ${
                questions[currentQuestion].id === 3 ? 'text-[#991B1B]' : 'text-[#6D28D9]'
              }`}
            >
              {questions[currentQuestion].question}
            </h2>

            <div className="space-y-4">
              {questions[currentQuestion].options.map((option) => (
                <motion.button
                  key={option.id}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleAnswer(option.id)}
                  className="w-full text-left p-6 bg-white border-2 border-gray-200 rounded-lg hover:border-[#6D28D9] hover:bg-purple-50 transition-all"
                >
                  <span className="font-semibold text-[#6D28D9] mr-3">{option.id}.</span>
                  <span className="text-gray-800">{option.text}</span>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
