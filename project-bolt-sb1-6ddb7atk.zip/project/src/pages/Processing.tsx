import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useQuiz } from '../contexts/QuizContext';
import { ArrowRight } from 'lucide-react';

const loadingMessages = [
  'Analizando Patrones de Dopamina...',
  'Calculando Nivel de Interés...',
  'Detectando Zona de Garantía...',
];

export default function Processing() {
  const [showLoading, setShowLoading] = useState(true);
  const [currentMessage, setCurrentMessage] = useState(0);
  const [emailInput, setEmailInput] = useState('');
  const { setEmail } = useQuiz();
  const navigate = useNavigate();

  useEffect(() => {
    const messageInterval = setInterval(() => {
      setCurrentMessage((prev) => (prev + 1) % loadingMessages.length);
    }, 1000);

    const loadingTimer = setTimeout(() => {
      setShowLoading(false);
    }, 3000);

    return () => {
      clearInterval(messageInterval);
      clearTimeout(loadingTimer);
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput.trim()) {
      setEmail(emailInput);
    }
    navigate('/vsl');
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-4">
      <AnimatePresence mode="wait">
        {showLoading ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              className="w-16 h-16 border-4 border-[#6D28D9] border-t-[#D97706] rounded-full mx-auto mb-6"
            />
            <motion.p
              key={currentMessage}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-xl text-[#6D28D9] font-semibold"
            >
              {loadingMessages[currentMessage]}
            </motion.p>
          </motion.div>
        ) : (
          <motion.div
            key="form"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl w-full"
          >
            <div className="bg-gradient-to-br from-[#991B1B] to-[#7F1D1D] text-white p-8 rounded-t-lg text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">ANÁLISIS CONCLUIDO... ⚠️</h2>
              <p className="text-lg leading-relaxed">
                Detectamos que estás atrapada en la 'Zona de Garantía'. El riesgo de fin definitivo
                es alto. Tu protocolo de corrección está listo.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="bg-white p-8 rounded-b-lg shadow-xl">
              <label className="block mb-4">
                <span className="text-gray-700 font-semibold mb-2 block">
                  Ingresa tu mejor correo electrónico (Opcional)
                </span>
                <input
                  type="email"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="tu@correo.com"
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-[#6D28D9] focus:outline-none"
                />
              </label>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full bg-[#6D28D9] text-white px-8 py-4 rounded-lg text-lg font-semibold border-2 border-[#D97706] shadow-lg hover:shadow-xl transition-shadow inline-flex items-center justify-center gap-2"
              >
                VER MI RESULTADO Y SOLUCIÓN
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
